import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_smart_course/src/helper/courseModel.dart';
import 'package:flutter_smart_course/src/helper/quad_clipper.dart';
import 'package:flutter_smart_course/src/pages/home_page.dart';
import 'package:flutter_smart_course/src/theme/color/light_color.dart';
import 'package:flutter_smart_course/src/theme/theme.dart';
import 'package:flutter_smart_course/src/pages/job_info_page.dart';

class ProfilePage extends StatelessWidget {
  ProfilePage({Key key}) : super(key: key);

  double width;
  String imgPath;

  Widget _header(BuildContext context) {
    var width = MediaQuery.of(context).size.width;

    Future<bool> _onBackPressed(){
      return  null;
    }

    return WillPopScope(
      onWillPop: _onBackPressed,
      child: ClipRRect(
        borderRadius: BorderRadius.only(
            bottomLeft: Radius.circular(50), bottomRight: Radius.circular(50)),
        child: Container(
            height: 120,
            width: width,
            decoration: BoxDecoration(
              color: LightColor.orange,
            ),
            child: Stack(
              fit: StackFit.expand,
              alignment: Alignment.center,
              children: <Widget>[
                Positioned(
                    top: 10,
                    right: -120,
                    child: _circularContainer(300, LightColor.lightOrange2)),
                Positioned(
                    top: -60,
                    left: -65,
                    child: _circularContainer(width * .5, LightColor.darkOrange)),
                Positioned(
                    top: -230,
                    right: -30,
                    child: _circularContainer(width * .7, Colors.transparent,
                        borderColor: Colors.white38)),
                Positioned(
                    top: 50,
                    left: 0,
                    child: Container(
                        width: width,
                        padding: EdgeInsets.symmetric(horizontal: 20),
                        child: Stack(
                          children: <Widget>[
                            GestureDetector(
                              onTap: (){
                                Navigator.push(context, MaterialPageRoute(builder: (context){
                                  return HomePage();
                                }));
                              },
                              child: Icon(
                                Icons.keyboard_arrow_left,
                                color: Colors.white,
                                size: 40,
                              ),
                            ),
                            Align(
                                alignment: Alignment.center,
                                child: Text(
                                  "Profile",
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 30,
                                      fontWeight: FontWeight.w500),
                                ))
                          ],
                        ))),
              ],
            )),
      ),
    );
  }

  Widget _circularContainer(double height, Color color,
      {Color borderColor = Colors.transparent, double borderWidth = 2}) {
    return Container(
      height: height,
      width: height,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color,
        border: Border.all(color: borderColor, width: borderWidth),
      ),
    );
  }

  Widget _profileInfo() {
    return SingleChildScrollView(
      scrollDirection: Axis.vertical,
      child: Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            CircleAvatar(
              backgroundImage: AssetImage('images/model1.png'),
              radius: 50.0,
            ),
            SizedBox(height: 20),
            Text('Richard Hendricks',
              textAlign: TextAlign.left,
              style: kTitleStyle),
            SizedBox(height: 20),
            Text('Credentials', style: TextStyle(
              fontWeight: FontWeight.w600,
                color: Colors.purple
            ),),
            Container(
              alignment: Alignment.topLeft,
              padding: EdgeInsets.all(20.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text('Degree Status:', style: kTextStyle),
                      SizedBox(height: 10.0,),
                      Text('Major Subject:', style: kTextStyle),
                      SizedBox(height: 10.0,),
                      Text('CGPA:', style: kTextStyle),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: <Widget>[
                      Text('Undergraduate', style: kTitleStyle.copyWith(fontSize: 15.0)),
                      SizedBox(height: 10.0,),
                      Text('Software Engineering', style: kTitleStyle.copyWith(fontSize: 15.0)),
                      SizedBox(height: 10.0,),
                      Text('3.74/4', style: kTitleStyle.copyWith(fontSize: 15.0)),
                    ],
                  )
                ],
              ),
            ),
            SizedBox(height: 10.0,),
            Text('Relevant Skills', style: TextStyle(
              fontWeight: FontWeight.w600,
              color: Colors.purple,
            ),),
            SizedBox(height: 10.0,),
            Container(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Column(
                    children: <Widget>[
                      Text('HTML', style: kSkillStyle),
                      SizedBox(height: 10.0,),
                      Text('CSS', style: kSkillStyle),
                      SizedBox(height: 10.0,),
                      Text('C++', style: kSkillStyle),
                      SizedBox(height: 10.0,),
                      Text('Java', style: kSkillStyle),
                      SizedBox(height: 10.0,),
                      Text('Python', style: kSkillStyle),
                      SizedBox(height: 10.0,),
                    ],
                  ),
                  Column(
                    children: <Widget>[
                      SizedBox(height: 10.0,),
                      Text('Flutter', style: kSkillStyle),
                      SizedBox(height: 10.0,),
                      Text('Android', style: kSkillStyle),
                      SizedBox(height: 10.0,),
                      Text('UI Design', style: kSkillStyle),
                      SizedBox(height: 10.0,),
                      Text('Adobe Premiere', style: kSkillStyle),
                      SizedBox(height: 10.0,),
                      Text('React Native', style: kSkillStyle),
                      SizedBox(height: 10.0,),
                    ],
                  )
                ],
              )
            ),
            SizedBox(height: 10.0,),
            Padding(
              padding: const EdgeInsets.only(left: 15.0, right: 15.0),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Text('University ', style: kTextStyle.copyWith(color: Colors.purple, fontWeight: FontWeight.w600),),
                    SizedBox(height: 10.0,),
                    Text('UET Taxila', style: kTextStyle.copyWith(color: Colors.deepOrangeAccent),),
                  ],
                  ),
              ),
            )
          ],
        ),
      ),
    );
  }


  BottomNavigationBarItem _bottomIcons(IconData icon) {
    return BottomNavigationBarItem(
        //  backgroundColor: Colors.blue,
        icon: Icon(icon),
        title: Text(""));
  }

  @override
  Widget build(BuildContext context) {
    width = MediaQuery.of(context).size.width;
    return Scaffold(
        bottomNavigationBar: BottomNavigationBar(
          showSelectedLabels: false,
          showUnselectedLabels: false,
          selectedItemColor: LightColor.purple,
          unselectedItemColor: Colors.grey.shade300,
          type: BottomNavigationBarType.fixed,
          currentIndex: 1,
          items: [
            _bottomIcons(Icons.home),
            _bottomIcons(Icons.person),
          ],
          onTap: (index) {
            Navigator.pushReplacement(
                context, MaterialPageRoute(builder: (context) => HomePage()));
          },
        ),
        body: SingleChildScrollView(
            child: Container(
          child: Column(
            children: <Widget>[
              _header(context),
              SizedBox(height: 20),
//              _categoryRow("Start a new career"),
              _profileInfo(),
            ],
          ),
        )));
  }
}

const kTitleStyle = TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.w400,
    letterSpacing: 1.1,
    color: Colors.redAccent,
  );

const kTextStyle = TextStyle(
  fontSize: 15,
  fontWeight: FontWeight.w400,
  color: Colors.black54,
);

const kSkillStyle = TextStyle(
  fontSize: 14,
  fontWeight: FontWeight.w500,
  color: Colors.black54,
);