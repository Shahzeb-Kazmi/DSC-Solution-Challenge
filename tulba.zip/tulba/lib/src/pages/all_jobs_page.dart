import 'package:flutter/material.dart';
import 'package:flutter_smart_course/global.dart';
import 'package:flutter_smart_course/src/helper/job_container.dart';
import 'package:flutter_smart_course/src/helper/bottom_sheet.dart';
import 'package:flutter_smart_course/src/helper/mydropdownbutton.dart';
import 'job_info_page.dart';


class AllJobs extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        body: Stack(
          children: <Widget>[
            Positioned(
              top: 0,
              right: 0,
              left: 0,
              bottom: 0,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15.0),
                child: Column(
                  children: <Widget>[
                    SizedBox(
                      height: 11.0,
                    ),
                    Container(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Text('All Jobs', style: TextStyle(
                            fontSize: 15,
                          ),),
                          Hero(
                            tag: 'tulbalogo',
                            child: CircleAvatar(
                              backgroundImage: AssetImage(
                                  'images/Tulba - Copy.png'),
                              radius: 25.0,
                            ),
                          ),
                        ],
                      ),
                    ),

                    SizedBox(
                      height: 11,
                    ),
                    Expanded(
                      child: ListView.builder(
                        itemCount: jobList.length,
                        itemBuilder: (ctx, i) {
                          return JobContainer(
                            description: jobList[i].description,
                            iconUrl: jobList[i].iconUrl,
                            location: jobList[i].location,
                            salary: jobList[i].salary,
                            title: jobList[i].title,
                            onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (ctx) => DetailsScreen(),
                              ),
                            ),
                          );
                        },
                      ),
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
